package com.example.moodapplication;

import android.os.ParcelUuid;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;


public class MainActivity extends AppCompatActivity {

    boolean buttonState1 = true;
    boolean buttonState2 = false;


    MqttAndroidClient mqttAndroidClient;

    final String serverUri = "tcp://192.168.31.204:1883";

    String clientId = "Aachal";
    final String publishTopic = "flat4";
    final String publishMessage1 = "0";
    final String publishMessage2 = "1";
    final String publishMessage3 = "2";
    final String publishMessage4 = "3";
    final String publishMessage5 = "4";
    final String publishMessage6 = "5";
    final String publishMessage7 = "6";
    final String publishMessage8 = "7";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imageView = (ImageView) findViewById(R.id.pic_1);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonState1) {
                    publishMessage(publishMessage2);
                    publishMessage(publishMessage3);
                    publishMessage(publishMessage5);
                    publishMessage(publishMessage8);
                }

                buttonState1 = !buttonState1;
                Toast.makeText(MainActivity.this, "click on study mood", Toast.LENGTH_SHORT).show();
            }
        });
        final ImageView one = (ImageView) findViewById(R.id.imageView);
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonState1) {
                    publishMessage(publishMessage2);
                    one.setImageResource(R.drawable.yellow1);
                    Toast.makeText(MainActivity.this, "button is on", Toast.LENGTH_SHORT).show();
                } else {
                    publishMessage(publishMessage1);
                    one.setImageResource(R.drawable.white1);
                    Toast.makeText(MainActivity.this, "button is off", Toast.LENGTH_SHORT).show();
                }

                buttonState1=!buttonState1;

            }
        });



        ImageView imageView1 = (ImageView) findViewById(R.id.pic_2);
        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonState1){
                    publishMessage(publishMessage1);
                    publishMessage(publishMessage4);
                    publishMessage(publishMessage6);
                    publishMessage(publishMessage8);
                }

                Toast.makeText(MainActivity.this, "click on sleep mood", Toast.LENGTH_SHORT).show();
              buttonState1=!buttonState1;
            }
        });



        final ImageView two = (ImageView) findViewById(R.id.imageView2);
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonState1) {
                    publishMessage(publishMessage3);
                    two.setImageResource(R.drawable.yellow2);
                    Toast.makeText(MainActivity.this, "button is on", Toast.LENGTH_SHORT).show();
                } else {
                    publishMessage(publishMessage4);
                    two.setImageResource(R.drawable.white2);
                    Toast.makeText(MainActivity.this, "button is off", Toast.LENGTH_SHORT).show();
                }

                buttonState1=!buttonState1;

            }
        });

        ImageView imageView2 = (ImageView) findViewById(R.id.pic_3);
        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonState1){
                    publishMessage(publishMessage1);
                    publishMessage(publishMessage4);
                    publishMessage(publishMessage5);
                    publishMessage(publishMessage7);
                }

                Toast.makeText(MainActivity.this, "click on wake up mood", Toast.LENGTH_SHORT).show();
                buttonState1=!buttonState1;
            }
        });



        final ImageView three = (ImageView) findViewById(R.id.imageView3);
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonState1) {
                    publishMessage(publishMessage5);
                    three.setImageResource(R.drawable.yellow3);
                    Toast.makeText(MainActivity.this, "button is on", Toast.LENGTH_SHORT).show();
                } else {
                    publishMessage(publishMessage6);
                    three.setImageResource(R.drawable.white3);
                    Toast.makeText(MainActivity.this, "button is off", Toast.LENGTH_SHORT).show();
                }

                buttonState1=!buttonState1;

            }
        });

        ImageView imageView3 = (ImageView) findViewById(R.id.pic_4);
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonState1) {
                    publishMessage(publishMessage3);
                    publishMessage(publishMessage2);
                    publishMessage(publishMessage5);
                    publishMessage(publishMessage7);
                }



                Toast.makeText(MainActivity.this, "click on eating mood", Toast.LENGTH_SHORT).show();
                buttonState1=!buttonState1;
            }
        });
        final ImageView four = (ImageView) findViewById(R.id.imageView4);
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonState1) {
                    publishMessage(publishMessage7);
                    four.setImageResource(R.drawable.yellow4);
                    Toast.makeText(MainActivity.this, "button is on", Toast.LENGTH_SHORT).show();
                } else {
                    publishMessage(publishMessage8);
                    four.setImageResource(R.drawable.white4);
                    Toast.makeText(MainActivity.this, "button is off", Toast.LENGTH_SHORT).show();
                }

                buttonState1=!buttonState1;

            }
        });


        clientId = clientId + System.currentTimeMillis();

        mqttAndroidClient = new MqttAndroidClient(getApplicationContext(), serverUri, clientId);
        mqttAndroidClient.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {

                if (reconnect) {
                    // addToHistory("Reconnected to : " + serverURI);
                    // Because Clean Session is true, we need to re-subscribe
                    //subscribeToTopic();
                } else {
                    //addToHistory("Connected to: " + serverURI);
                }
            }

            @Override
            public void connectionLost(Throwable cause) {
                //    addToHistory("The Connection was lost.");
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                //  addToHistory("Incoming message: " + new String(message.getPayload()));
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });

        MqttConnectOptions mqttConnectOptions = new MqttConnectOptions();
        mqttConnectOptions.setAutomaticReconnect(true);
        mqttConnectOptions.setCleanSession(false);

        try {
            //addToHistory("Connecting to " + serverUri);
            mqttAndroidClient.connect(mqttConnectOptions, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    DisconnectedBufferOptions disconnectedBufferOptions = new DisconnectedBufferOptions();
                    disconnectedBufferOptions.setBufferEnabled(true);
                    disconnectedBufferOptions.setBufferSize(100);
                    disconnectedBufferOptions.setPersistBuffer(false);
                    disconnectedBufferOptions.setDeleteOldestMessages(false);
                    mqttAndroidClient.setBufferOpts(disconnectedBufferOptions);
                    //  subscribeToTopic();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    //addToHistory("Failed to connect to: " + serverUri);
                }
            });


        } catch (MqttException ex){
            ex.printStackTrace();
        }

    }

    public void publishMessage(String publishMessage){

        try {
            MqttMessage message = new MqttMessage();
            message.setPayload(publishMessage.getBytes());
            mqttAndroidClient.publish(publishTopic, message);
            //   addToHistory("Message Published");
            if(!mqttAndroidClient.isConnected()){
                //addToHistory(mqttAndroidClient.getBufferedMessageCount() + " messages in buffer.");
            }
        } catch (MqttException e) {
            System.err.println("Error Publishing: " + e.getMessage());
            e.printStackTrace();
        }

    }
}

